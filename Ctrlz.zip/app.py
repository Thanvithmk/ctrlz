from flask import Flask, jsonify, render_template, request
import pandas as pd

app = Flask(__name__)

# Load the dataset
try:
    df = pd.read_csv('agri.csv')  # Ensure 'agri.csv' exists in the same directory
    print("CSV loaded successfully!")
except FileNotFoundError:
    print("Error: 'agri.csv' not found.")
    df = None

# Function to predict sustainable practices based on region and climate
def predict_sustainable_practices(region, climate):
    if df is None:
        return None, "Dataset not loaded. Please check the 'agri.csv' file."

    # Filter the dataset for the given region and climate
    filtered_data = df[(df['region'].str.lower() == region.lower()) & (df['climate'].str.lower() == climate.lower())]
    
    if filtered_data.empty:
        return None, "No recommendations found for this region and climate."

    # Get the primary crop recommendations for the filtered data
    recommendations = filtered_data['Primary Crops'].iloc[0]
    return recommendations, None

# Route for Home Page
@app.route('/')
def home():
    return render_template('index.html')

# Route for Predict
@app.route('/predict', methods=['POST'])
def predict():
    region = request.form.get('region')
    climate = request.form.get('climate')

    if not region or not climate:
        return jsonify({'error': 'Please enter both region and climate!'}), 400

    recommendations, error = predict_sustainable_practices(region, climate)
    
    if error:
        return jsonify({'error': error}), 404

    return jsonify({'recommendations': recommendations, 'region': region, 'climate': climate})

if __name__ == '__main__':
    app.run(debug=True)
